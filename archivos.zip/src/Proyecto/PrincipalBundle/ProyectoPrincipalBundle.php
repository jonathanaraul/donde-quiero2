<?php

namespace Proyecto\PrincipalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProyectoPrincipalBundle extends Bundle
{
}
