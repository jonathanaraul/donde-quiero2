function checksApagados(clase){
    var prueba = true;
    var elementos  = $('.'+clase);
  $.each(elementos, function(indice, valor) {
    
        if($(valor).is(":checked"))
        {
          prueba= false;
        }
  });
    return prueba;
}


<!-- ------------------- SCROLL TO START ------------------- -->
            $(function() {
                $('nav ul li a').bind('click',function(event){
                    var $anchor = $(this);
                    
                    $('html, body').stop().animate({
                        scrollTop: $($anchor.attr('href')).offset().top
                    }, 1500,'easeInOutExpo');
                    event.preventDefault();
                });
            });
<!-- ------------------- SCROLL TO END ------------------- -->
	   
<!-- ------------------- FORM TEXT STYLE START ------------------- -->

   $(document).ready(function() {
 $('input[title]').each(function() {
  if($(this).val() === '') {
   $(this).val($(this).attr('title')); 
  }
  
  $(this).focus(function() {
   if($(this).val() === $(this).attr('title')) {
    $(this).val('').addClass('focused'); 
   }
  });
  
  $(this).blur(function() {
   if($(this).val() === '') {
    $(this).val($(this).attr('title')).removeClass('focused'); 
   }
  });
 });
  $('textarea[title]').each(function() {
  if($(this).val() === '') {
   $(this).val($(this).attr('title')); 
  }
  
  $(this).focus(function() {
   if($(this).val() === $(this).attr('title')) {
    $(this).val('').addClass('focused'); 
   }
  });
  
  $(this).blur(function() {
   if($(this).val() === '') {
    $(this).val($(this).attr('title')).removeClass('focused'); 
   }
  });
 });
});
<!-- ------------------- FORM TEXT STYLE END ------------------- -->

<!-- ------------------- FORM SUBMIT START ------------------- -->
	$(document).ready(function() {
		$('#submitform').ajaxForm({
			target: '#error',
			success: function() {
			$('#error').fadeIn('slow');
			}
		});
	});
<!-- ------------------- FORM SUBMIT END ------------------- -->

